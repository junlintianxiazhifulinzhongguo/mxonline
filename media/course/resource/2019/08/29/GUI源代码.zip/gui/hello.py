"""一个实现四则运算的计算器"""


def add(a,b):
    return a+b

def minus(a,b):
    return a-b


class MyNum():
    def print123(self):
        print(123)